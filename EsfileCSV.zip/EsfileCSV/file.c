#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#define DIM 20
#define NUMCAT 5
typedef struct
{
    char titolo[DIM];
    char autore[DIM];
    int annoP;
    float prezzo;

} Libro;

typedef struct
{
    char categoria[40];//nome categoria
    Libro libri[50];//array di libri
    int numero_libri;//num libri per categoria
} Categoria;

Categoria categorie[NUMCAT];
char nomeCategoria[30];



void caricaLibri(char *nomeCategoria , int *num_categorie) {
    
    FILE *file = fopen("libreria_libri.csv", "r");
    if (!file) {
        printf("Errore nell'apertura del file CSV.\n");
        exit(0);  
    }

    char riga[30];
    while (fgets(riga, sizeof(riga), file)) {
        Libro nuovo_libro;  // Struttura per memorizzare i dati di un libro
        char categoria[40]; // Categoria letta dal file
        int campo = 0; 
        int lunghezza_riga = strlen(riga);
        int i, j = 0;

        char temp[30] = {0};  // Buffer temporaneo per ciascun campo
        for (i = 0; i <= lunghezza_riga; i++) {
            if (riga[i] == ',' || riga[i] == '\n' || riga[i] == '\0') {
                temp[j] = '\0';  // Termina la stringa temporanea

                // Assegna il valore al campo corrente in base a 'campo'
                switch (campo) {
                    case 0: strcpy(nuovo_libro.titolo, temp); break;
                    case 1: strcpy(nuovo_libro.autore, temp); break;
                    case 2: nuovo_libro.anno = atoi(temp); break;
                    case 3: nuovo_libro.prezzo = atof(temp); break;
                    case 4: strcpy(categoria, temp); break;
                }
                
                // Reset per il prossimo campo
                j = 0;
                campo++;
            } else {
                temp[j++] = riga[i];  // Continua a leggere il campo
            }
        }

        aggiungiLibro(categorie, num_categorie, categoria, nuovo_libro);
    }
    
    printf("Tutti i libri sono stati aggiunti.\n");
    fclose(file);  // Chiudi il file al termine
}

// Aggiunge un libro alla categoria corretta
void aggiungiLibro(Categoria *categorie, int *num_categorie, char *categoria, Libro nuovo_libro) {
    for (int i = 0; i < NUMCAT; i++) {
        if (strcmp(categorie[i].categoria, categoria) == 0) {
            categorie[i].libri[categorie[i].numero_libri] = nuovo_libro;
            categorie[i].numero_libri++;// Incrementa il numero di libri
            return;
        }
    }
}
// Funzione per visualizzare i libri di una categoria
void Visualizza(char *nomeCategoria)
{
    for (int i = 0; i < NUMCAT; i++)
    {
        if (strcmp(categorie[i].categoria, nomeCategoria) == 0)
        {
            printf("Libri nella categoria '%s':\n", nomeCategoria);
            for (int j = 0; j < categorie[i].numero_libri; j++)
            {
                Libro libro = categorie[i].libri[j];
                printf("Titolo: %s, Autore: %s, Anno: %d, Prezzo: %.2f\n",
                       libro.titolo, libro.autore, libro.annoP, libro.prezzo);
            }
            
            return;
        }
    }
    printf("Categoria non trovata.\n");
}
// Funzione per cercare un libro per titolo
void Cerca_libro(char *titolo)
{
    rimuoviNewline(titolo);
    for (int i = 0; i < NUMCAT; i++)
    {
        for (int j = 0; j < categorie[i].numero_libri; j++)
        {
            Libro libro = categorie[i].libri[j];
            if (strcmp(libro.titolo, titolo) == 0)
            {
                printf("Libro trovato: %s, Autore: %s, Anno: %d, Prezzo: %.2f\n",
                       libro.titolo, libro.autore, libro.annoP, libro.prezzo);
                return;
            }
        }
    }
    printf("Libro non trovato.\n");
}

int main()
{

    char tit[30];
    int scelta;
    
    strcpy(categorie[0].categoria, "letteratura");
    strcpy(categorie[1].categoria, "narrativa");
    strcpy(categorie[2].categoria, "scienza");
    strcpy(categorie[3].categoria, "fantasy");
    
       // Carica i libri dal file CSV
    caricaLibri(nomeCategoria, NULL);
    
    do
    {
        printf("\nMenu:\n");
        printf("1. Visualizza libri per categoria\n");
        printf("2. Cerca libro per titolo\n");
        printf("3. Esci\n");
        printf("Scegli un'opzione: ");
        scanf("%d", &scelta);

        switch (scelta) {
            case 1:
            printf("Inserisci la categoria da ricercare:narrativa/scienza/romanzo/letteratura: \n");
            scanf("%s",nomeCategoria);
            Visualizza(nomeCategoria);
            break;
            case 2:
                printf("Inserisci il titolo del libro da cercare: ");
                scanf("%s", tit);
                Cerca_libro(tit);
            break;
            case 3:
                printf("Uscita dal programma...\n");
                break;
            default:
                printf("Opzione non valida. Riprova.\n");
        }

    }while(scelta != 3);

    return 0;
}